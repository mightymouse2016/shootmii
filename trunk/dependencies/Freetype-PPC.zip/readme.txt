FreeType 2.3.7

This is compiled with only TrueType and Postscript Type1 font support. To change the compiled options, just edit modules.cfg and recompile. See the source folder for instructions.

Installing

Copy the include and lib folders to your libogc folder. That's it! Usage examples on: http://code.google.com/p/snes9x-gx/

- Tantric, November 2008